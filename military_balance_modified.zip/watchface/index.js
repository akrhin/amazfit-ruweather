﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_spo2_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_pressure_text_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        //dynamic modify end

        // RuWeather integration start
        // RuWeather stores data in weather.json and forecast.json
        // See: https://starrrscream.github.io/website/
        
        function arrayBufferToCyrillic(buffer) {
          let result = '';
          const bytes = new Uint8Array(buffer);

          let i = 0;
          while (i < bytes.length) {
            let byte1 = bytes[i++];

            // Обработка 1-байтовых символов (ASCII)
            if (byte1 < 0x80) {
              result += String.fromCharCode(byte1);
            }
            // Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
            else if (byte1 >= 0xC0 && byte1 < 0xE0) {
              let byte2 = bytes[i++];
              let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
              result += String.fromCharCode(charCode);
            }
            // Обработка 3-байтовых символов (например, для UTF-8)
            else if (byte1 >= 0xE0 && byte1 < 0xF0) {
              let byte2 = bytes[i++];
              let byte3 = bytes[i++];
              let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
              result += String.fromCharCode(charCode);
            }
          }

          return result;
        }

        function read_weather_data_str() {
          console.log('start read weather data');
          let str_result = "";
          try {
            const file_name = "weather.json"; //указываем путь к файлу данных weather.json или forecast.json
            const mini_app_id = 1066654; //указываем ID приложения

            const [fs_stat, err] = hmFS.stat(file_name, {
              appid: mini_app_id
            });
            if (err == 0) {
              //console.log('--->size_alt:', fs_stat.size);

              const fh = hmFS.open(file_name, hmFS.O_RDONLY, {
                appid: mini_app_id
              })

              const len = fs_stat.size;
              let array_buffer = new ArrayBuffer(len);
              hmFS.read(fh, array_buffer, 0, len);
              hmFS.close(fh);
              str_result = arrayBufferToCyrillic(array_buffer);
              //console.log(`str_result = ${str_result}`);
              return str_result;

            } else {
              console.log('err:', err)
            }

          } catch (error) {
            console.log('error:', error);
            console.log("FAIL: No access to hmFS.");
          }
          return "";
        }

        function getWeatherValue(str = "", key) {
          let value = 0;
          try {
            const data = JSON.parse(str); //получаем массив данных
            //присваиваем виджетам их значения
            if (data[key] !== undefined) {
              value = data[key];
            }
          } catch (error) {
            console.log('error:', error);
          }
          return value;
        }

        function getDataValue(str = "") {
          let value = 0;
          try {
            const data = JSON.parse(str); //получаем массив данных
            //присваиваем виджетам их значения
            normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT, data.temperature + '°') //присваиваем виджетам их значения
            idle_temperature_current_text_font.setProperty(hmUI.prop.TEXT, data.temperature + '°')

            wCurTemp.setProperty(hmUI.prop.TEXT, data.temperature + '°(' + data.temperatureFeels + '°)')
            wCity.setProperty(hmUI.prop.TEXT, data.city)
            wUpdate.setProperty(hmUI.prop.TEXT, data.weatherTimeStr)

          } catch (error) {
            console.log('error:', error);
          }

        }

        function updateWeatherApp() {
          console.log('update_weather_from_app')
          let read_str = read_weather_data_str();
          getDataValue(read_str);
        }
        // RuWeather integration end

        //#endregion
        function scale_call() {
          console.log('scale_call()');

              // Use RuWeather data instead of built-in weather sensor
              updateWeatherApp();
              
              /* Old code - using weather sensor
              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);
              */
        };

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');
            scale_call();
            text_update();
            if (screenType == hmSetting.screen_type.AOD) {
              if (!idle_timerTextUpdate) {
                idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                  text_update();
                }));  // end timer 
              };  // end timer check
            };  // end screenType